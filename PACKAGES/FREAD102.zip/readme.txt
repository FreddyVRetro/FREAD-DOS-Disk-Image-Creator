FREAD: Floppy disk reader by FreddyV v1.02 April 2021

Create a .IMG file using the standard BIOS 13h interrupt.
Perform sector by sector read if a track fail.
Create a .LOG file to list the sectors with error.

Read only the floppy with the 512 Bytes sectors.